import xml.etree.ElementTree as ET
tree = ET.parse('/home/mta/Bureau/Implementation Algo/code/xml_chunks/repository.xml')
root = tree.getroot()


les_noeuds = [{'I2':'Start'},{'I3':'Define Readiness dimension'},
    {'I4':'Collect Dimension Data'}, 
    {'I5':'Compute Dimensions Weights'},
    {'I6':'Analyse Readiness'},
    {'I7':'Identify Factors to improve'},
    {'I8':'Define an improvement plan'},
    {'I1':'Stop'}]

def smalldist(org, exigcudic):
    # prend le dico de besoin, fait le mapping avec le dico de org et renvoie la distance
    d = 1
    if exigcudic['attribute'].lower() == 'skill':
        #print('dans exidic')
        if exigcudic['value'].lower() in org['skill']:
            d = 0
            #print(exigcudic['value'] in org['skill'],' In skill ', )
    elif exigcudic['attribute'].lower() == 'profile':
        if exigcudic['value'].lower() in org['profile']:
            d = 0 
            #print('In profile')
    else:
        print('pas de skill ou profile')

    return d

def calculDistance(org,exigcu, exigorg):
    """ Calcul la distance entre besoin et exigence: 
    
    org est de la forme {'cult':cult, 'hucomp':hucomp, 'huexp':huexp, 'budg':budg, 
        'infra':infra, 'skill':condskill, 'profile': condprofile }

    exig est de la forme 
        
        exiorg: [{'budlev': 'LOW', 'infralev': 'LOW', 'huskilev': 'MEDIUM', 
        'huexplev': 'MEDIUM', 'cultor': 'HIGHLY SUBJECTIVE'}]  
        
        exicu: [{},{'object': 'stakeholder', 'attribute': 'Skill', 'value': 'Fuzzy set theory'},{}]  
        [{'operator': 'AND'}, {'object': 'stakeholder', 'attribute': 'Skill', 'value': 'D-S Combination'}, 
        {'object': 'stakeholder', 'attribute': 'Profile', 'value': 'Erp Expert'}]  
    
    """
    d1=0
    # distance exiorg 
    t = ('cult','hucomp','huexp','budg','infra')
    if exigorg!=[]:
        dic = exigorg[0]
        #print(dic)
        for v in t:
            if v in dic.keys() and v in org.keys():
                #print(dic[v])
                #print(org[v])
                if dic[v].lower() == org[v].lower():
                    d1+=0
                else:
                    d1+=1
        
    d2=0
    # distance exigcu
    if len(exigcu)==3:
        # on recupere le dic
        
        op, exigcudic1, exigcudic2 = exigcu[0], exigcu[1], exigcu[2] 
        if op=={}:
            d2=smalldist(org, exigcudic1)
        elif op['operator'] == 'OR':
            d2 = smalldist(org, exigcudic1)*smalldist(org, exigcudic2)        
        elif op['operator'] == 'AND':
            d2 = smalldist(org, exigcudic1)+smalldist(org, exigcudic2)
        else:
            print("problem avec l'opérateur")
        
        #print("d2 = ",d2
    #print("d1+d2: ",d1+d2)
    #print(org, exigcu, exigorg)
    return d1+d2

def construireGraphChunk(org): #prend un dictionnaire d'arguments
    """ je veux obtenir les elements suivant par chunk: 
        le chunk
        le guide (je peux déduire les intentions)
        la contrainte d'utilisation à 2 elements avec l'opérateur : me permettra de calculer dconstraint
        les elements de contexte
    """
    graphe = []
    for el in root.findall("./erm_chunk"): #el c l'élément chunk
        # ----------- Ajout du chunk
        chunk = [el] # une liste de : [el_chunk,(I1, I2), dist]
        
        print('\n le chunk: ',chunk)

        # ---------------------- ajout des guides
        att_du_noeud = el.findall(".//*[@url]") # retourne un dictionnaire
        guide = att_du_noeud[0].attrib['url'] # retourne les guides
        c = guide.strip('IAG').split('.')
        tup = ('I'+c[0][0],'I'+c[1][0])
        
        chunk.append(guide)
        chunk.append(tup)

        print('\n le chunk avec tup: ',chunk)

        #--------------------- Ajout des distances
        #récupération des contraintes avec op un dico avec skill et profile 
        lis = []
        usageCond = el.find(".//*usage_condition")
        if usageCond.attrib == {}: # s'il n'ay pas d'attribut dans l'usage cond (on ne gere qu'une seule condition)          
            lis.append(usageCond.find('./condition').attrib)
            #print(lis)
        else: #s'il ya un attribut on gere les trois: 2 cond et operateur pour le calcul de distance
            #print(usageCond.attrib)
            lis.append(usageCond.attrib) # ajout de l'operateur à la liste vide
            #print(lis)
            for u in usageCond.findall('./condition'):
                #print("la liste {}".format(u.attrib))
                lis.append(u.attrib) # ajout de la liste des dic de conditions dans notre liste 
                #print("la liste {}".format(lis))
            print(" *")
        #dcond = calculDistance(lis)
        #print(usageCond.attrib)

        #récupération des éléments de contexte 
        """
        <> LOW</budget_level>
              <infrastructure_level> LOW	</infrastructure_level>
              <human_skills_level> LOW</human_skills_level>
              <human_experience_level> LOW </human_experience_level>
            </internal_context>
            <external_context>
              <culture_orientation>
              """
        budlev = el.find(".//*budget_level").text
        infralev = el.find(".//*infrastructure_level").text
        huskilev = el.find(".//*human_skills_level").text
        huexplev = el.find(".//*human_experience_level").text
        cultor = el.find(".//*culture_orientation").text
        lis2 = [{'budg':budlev,'infra':infralev, 'hucomp':huskilev, 'huexp':huexplev, 'cult':cultor}]
        #dcont = calculDistance(lis2)
        print(lis2)

        chunk.append(calculDistance(org, lis, lis2))

        print('\n le chunk avec dist: ',chunk)

        # récupérer les premier caractère et les mettre dans la liste
        #ajout de la structure finale au graphe
        graphe.append(chunk)
    
    return graphe


def initialisation():
    print("Defining the Organization's context \n\n")
    cult = input("What is the level of Culture Orientation: Highly SUbjective, Subjective, Objective ? \n")
    hucomp = input("What is the level of Human Competences: Low, Medium, High ? \n")
    huexp = input("What is the level of Human Experience: Low, Medium, High ? \n")
    budg = input("What is the level of Budget: Low, Medium, High ? \n")
    infra = input("What is the level of Local infrastructure in the organization: Low, Medium, High ? \n")
    print("\n Usage Constraints \n")
    condskill = input("""Necessary available or affordable skills between stakeholders: literature review, survey analysis, 
        ontology, fuzzy set theory, analytic Hierarchy process, d-s combination, fuzzy cognitive map, fuzzy analytic network process, fuzzy expert system, mathematic, dematel, NSGA II """).lower()
    condprofile=""
    if input("Can you afford more than two Erp experts? Yes or No \n").lower() == 'yes':
        condprofile = "erp experts"
    

    return {'cult':cult, 'hucomp':hucomp, 'huexp':huexp, 'budg':budg, 'infra':infra, 'condskill':condskill, 'condprofile': condprofile }
    
    
def calculChemin(graphe):
    return True


def mon_algo():
    # récupérer les paramètres de l'org 
    #org = initialisation() # doit renvoyer un dictionnaire
    # construction du graphe connaissant le contexte de l'org

    org = {'cult':'subjective', 'hucomp':'low', 'huexp':'medium', 'budg':'medium', 
        'infra':'low', 
        'skill':('fuzzy set theory', 'analytic Hierarchy process', 'd-s combination'),
        'profile': 'erp experts' }
    graphe = construireGraphChunk(org)

    print("\n\n Le graphe final est: ",graphe)
    # Identifier la distance 
    chemin = calculChemin(graphe)

    return chemin 


if __name__=='__main__':
    print("""
        
    *********************************
    OUTIL D'AIDE A LA CONSTRUCTION D'UNE METHODE ERM
    *********************************

    Bienvenue


    """)

    mon_algo()
    # Partir du repo et construire la liste globale des chunks (edges)
    #l = repoToChunk()
    # Construction du graphe equivalent : une liste de couple (intention init, 
    # intention fin) pour chaque chunk: les noeuds
    #g1 = repoTograph(l)

    # Recupération des informations contextuelles