from xml.dom import minidom
doc = minidom.parse('xml_chunks/repository.xml')
root = doc.documentElement
 
#c = root.childNodes
#print(c)
#help(c) 

#current = root.firstChild

#while current:    
#    print(type(current))
#    current = current.nextSibling

l = list()


def distanceElement(element, **argv):
    # récupération des valeurs usage cond et org context
    # test avec le premier element
    dcond, dorg = 0,0
    #Cancul pour dcond
    usagecond = element.getElementsByTagName('usage_condition')[0]
    #if usagecond.hasAttribute('operator'):
    cond = usagecond.getElementsByTagName('condition')
    if len(cond>0):
        cond1 = cond[0] #"recu de la premier cond"
        dcond1 = calculDist(cond1,**argv) # caldul dist du premier cond
        if len(usagecond.size) >1: # en cas de 2 cond
            cond2 = cond[1] 
            dcond2 = calculDist(cond2,**argv)
        if usagecond.getAttribute('operator')== "OR":
            dcond = dcond1+dcond2    
        elif usagecond.getAttribute('operator')== "AND":
            dcond = dcond1*dcond2  
        else:
            dcond = dcond1
    
    # org context
    org = element.getElementsByTagName('budget_level')[0]
    dorg


    print(dcond+dorg)

for element in root.getElementsByTagName('erm_chunk'):
    #print(element.tagName)
    # creation d'un tuple (chunk,Iag)
   # t = (element,)
    #l.append(e)
    # constructino des intentions à partir des guides
    guide = element.getElementsByTagName('erm_chunk_body')[0].getAttribute('url')
    # strip enleve IAG, split enleve le point et nous renvoie une liste de 2 chaines
    # a chaque chaine on recupere juste le premier element pour construire les intentions
    c = guide.strip('IAG').split('.')
    # récupérer les premier caractère et les mettre dans la liste
    t = (element,'I'+c[0][0],'I'+c[1][0])
    l.append(t)

#print(l)
# Nous voulons à la fin construire une liste dont 
# les élements seront le chemin de la méthode

# calcul des distances

if __name__=='__main__':
    distanceElement()