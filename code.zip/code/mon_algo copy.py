
from xml.dom import minidom
doc = minidom.parse('xml_chunks/repository.xml')
root = doc.documentElement

def repoToChunk():
    pass

les_noeuds = [{'I2':'Start'},{'I3':'Define Readiness dimension'},
    {'I4':'Collect Dimension Data'}, 
    {'I5':'Compute Dimensions Weights'},
    {'I6':'Analyse Readiness'},
    {'I7':'Identify Factors to improve'},
    {'I8':'Define an improvement plan'},
    {'I1':'Stop'}]

def distanceElement(element, **argv):
    # récupération des valeurs usage cond et org context
    #le parcours de usage cond doit se faire de manière récursive 
    # car un Uc peut en contenir un autre
    #on teste s'il ya un attribut pour décider de l'opération à opter
    usagecond = element.getElementsByTagName('usage_condition')[0]
    return 0

def construireGraphChunk(**argv): #prend un dictionnaire d'arguments
    l = list()

    for element in root.getElementsByTagName('erm_chunk'):
        print(element.tagName)
        # creation d'un tuple (chunk,Iag)
        # t = (element,)
        #l.append(e)
        # constructino des intentions à partir des guides
        guide = element.getElementsByTagName('erm_chunk_body')[0].getAttribute('url')
        # strip enleve IAG, split enleve le point et nous renvoie une liste de 2 chaines
        # a chaque chaine on recupere juste le premier element pour construire les intentions
        c = guide.strip('IAG').split('.')
        # récupérer les premier caractère et les mettre dans la liste
        t = (element,'I'+c[0][0],'I'+c[1][0], distanceElement(element,**argv))
        l.append(t)

    print(l)

def initialisation():
    print("Defining the Organization's context \n\n")
    cult = input("What is the level of Culture Orientation: Highly SUbjective, Subjective, Objective ? \n")
    hucomp = input("What is the level of Human Competences: Low, Medium, High ? \n")
    huexp = input("What is the level of Human Experience: Low, Medium, High ? \n")
    budg = input("What is the level of Budget: Low, Medium, High ? \n")
    infra = input("What is the level of Local infrastructure in the organization: Low, Medium, High ? \n")
    print("\n Usage Constraints \n")
    condskill = input("""Necessary available or affordable skills between stakeholders: Literature review, Survey analysis, 
        Ontology, Fuzzy Set, AHP, D-S, FCM, FANP, FES, Mathematic, Dematel, NSGA II """).lower()
    condprofile=""
    if input("Can you afford more than two Erp experts? Yes or No \n").lower() == 'yes':
        condprofile = "erp experts"
    

    return {'cult':cult, 'hucomp':hucomp, 'huexp':huexp, 'budg':budg, 'infra':infra, 'condskill':condskill, 'condprofile': condprofile }
    
    
def calculChemin(*arg):
    return True


def mon_algo():
    # récupérer les paramètres de l'org 
    org = initialisation() # doit renvoyer un dictionnaire
    # construction du graphe connaissant le contexte de l'org
    graphe = construireGraphChunk(org)
    # Identifier la distance 
    chemin = calculChemin(graphe)

    return chemin 


if __name__=='__main__':
    print("""
        
    *********************************
    OUTIL D'AIDE A LA CONSTRUCTION D'UNE METHODE ERM
    *********************************

    Bienvenue


    """)

    
    # Partir du repo et construire la liste globale des chunks (edges)
    #l = repoToChunk()
    # Construction du graphe equivalent : une liste de couple (intention init, 
    # intention fin) pour chaque chunk: les noeuds
    #g1 = repoTograph(l)

    # Recupération des informations contextuelles