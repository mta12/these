import xml.etree.ElementTree as ET
tree = ET.parse('xml_chunks/repository.xml')
root = tree.getroot()

def smalldist(org, exigcudic):
    # prend le dico de besoin, fait le mapping avec le dico de org et renvoie la distance
    d = 1
    if exigcudic['attribute'].lower() == 'skill':
        #print('dans exidic')
        if exigcudic['value'].lower() in org['skill']:
            d = 0
            #print(exigcudic['value'] in org['skill'],' In skill ', )
    elif exigcudic['attribute'].lower() == 'profile':
        if exigcudic['value'].lower() in org['profile']:
            d = 0 
            #print('In profile')
    else:
        print('pas de skill ou profile')

    return d

def calculDistance(org,exigcu, exigorg):
    """ Calcul la distance entre besoin et exigence: 
    
    org est de la forme {'cult':cult, 'hucomp':hucomp, 'huexp':huexp, 'budg':budg, 
        'infra':infra, 'skill':condskill, 'profile': condprofile }

    exig est de la forme 
        
        exiorg: [{'budlev': 'LOW', 'infralev': 'LOW', 'huskilev': 'MEDIUM', 
        'huexplev': 'MEDIUM', 'cultor': 'HIGHLY SUBJECTIVE'}]  
        
        exicu: [{},{'object': 'stakeholder', 'attribute': 'Skill', 'value': 'Fuzzy set theory'},{}]  
        [{'operator': 'AND'}, {'object': 'stakeholder', 'attribute': 'Skill', 'value': 'D-S Combination'}, 
        {'object': 'stakeholder', 'attribute': 'Profile', 'value': 'Erp Expert'}]  
    
    """
    d1=0
    # distance exiorg 
    t = ('cult','hucomp','huexp','budg','infra')
    if exigorg!=[]:
        dic = exigorg[0]
        print(dic)
        for v in t:
            if v in dic.keys() and v in org.keys():
                #print(dic[v])
                #print(org[v])
                if dic[v].lower() == org[v].lower():
                    d1+=0
                else:
                    d1+=1
        
    d2=0
    # distance exigcu
    if len(exigcu)==3:
        # on recupere le dic
        
        op, exigcudic1, exigcudic2 = exigcu[0], exigcu[1], exigcu[2] 
        if op=={}:
            d2=smalldist(org, exigcudic1)
        elif op['operator'] == 'OR':
            d2 = smalldist(org, exigcudic1)*smalldist(org, exigcudic2)        
        elif op['operator'] == 'AND':
            d2 = smalldist(org, exigcudic1)+smalldist(org, exigcudic2)
        else:
            print("problem avec l'opérateur")
        
        print("d2 = ",d2)

    #print("d1+d2: ",d1+d2)
    #print(org, exigcu, exigorg)
    return d1+d2


def test():
    #print(root.findall("./erm_chunk/erm_chunk_guideline/erm_chunk_interface/situation"))
    """ je veux obtenir les elements suivant par chunk: 
        le chunk
        le guide (je peux déduire les intentions)
        la contrainte d'utilisation à 2 elements avec l'opérateur : me permettra de calculer dconstraint
        les elements de contexte
    """
    for el in root.findall("./erm_chunk"): #el c l'élément chunk
        att_du_noeud = el.findall(".//*[@url]") # retourne un dictionnaire
        guide = att_du_noeud[0].attrib['url'] # retourne les guides

        c = guide.strip('IAG').split('.')
        print('I'+c[0][0],'I'+c[1][0])
        #print(type(val_url))

        #récupération des contraintes avec op un dico avec skill et profile 
        lis = []
        usageCond = el.find(".//*usage_condition")
        if usageCond.attrib == {}: # s'il n'ay pas d'attribut dans l'usage cond (on ne gere qu'une seule condition)          
            lis.append({})
            lis.append(usageCond.find('./condition').attrib)
            lis.append({}) # pour avoir [{},{di},{}]
            print(lis)
        else: #s'il ya un attribut on gere les trois: 2 cond et operateur pour le calcul de distance
            #print(usageCond.attrib)
            lis.append(usageCond.attrib) # ajout de l'operateur à la liste vide
            #print(lis)
            for u in usageCond.findall('./condition'):
                #print("la liste {}".format(u.attrib))
                lis.append(u.attrib) # ajout de la liste des dic de conditions dans notre liste 
                print("la liste {}".format(lis))
            print(" *")
        #dcond = calculDistance(lis)
        #print(usageCond.attrib)

        #récupération des éléments de contexte 
        """
        <> LOW</budget_level>
              <infrastructure_level> LOW	</infrastructure_level>
              <human_skills_level> LOW</human_skills_level>
              <human_experience_level> LOW </human_experience_level>
            </internal_context>
            <external_context>
              <culture_orientation>
              """
        budlev = el.find(".//*budget_level").text
        infralev = el.find(".//*infrastructure_level").text
        huskilev = el.find(".//*human_skills_level").text
        huexplev = el.find(".//*human_experience_level").text
        cultor = el.find(".//*culture_orientation").text
        # une liste d'un seul element dictionnaire

        lis2 = [{'budg':budlev,'infra':infralev, 'hucomp':huskilev, 'huexp':huexplev, 'cult':cultor}]
        #dcont = calculDistance(lis2)
        print(lis2)

if __name__=='__main__':
    #    exemple de calcul de distance
    d = calculDistance({'cult':"objective", 'skill': ('fuzzy set theory',)},[{},{'object': 'stakeholder', 'attribute': 'Skill', 'value': 'Fuzzy set theory'},{}], [{'budg': 'LOW'}])